#include "asunto.h"
#include <iostream>
using namespace std;
Asunto::asunto()
{
   // asunto();
    cout<<"Asunto has been created"<<endl;
}

void Asunto::maarita(int a, int b)
{
    residents= a;
    squares= b;
   // cout<<"Asunto defined, residents equal to= "<<residents<<"and squares equal to"<<squares<<endl;
    cout << "Asunto defined, residents equal to= " << residents << " and squares equal to " << squares << endl;


}

double Asunto::calculateConsumtion(double h, bool printOrNot)
{
    double consumption= h*residents * squares;
    if (printOrNot==true)
    {
        cout<< "Asunto consumption equals when price= "<<h<<"equals to"<< consumption<<endl;

    }

    return consumption;
}
