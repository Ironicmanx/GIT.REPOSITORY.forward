#include <iostream>
#include "asunto.h"
using namespace std;

int main()
{

    Asunto olio;
    olio.maarita(2,100);
    //olio.calculateConsumtion(1);
    cout << "Apartment!! consumption when price equals to 1 is" << olio.calculateConsumtion(1, false) << endl;



    return 0;
}
