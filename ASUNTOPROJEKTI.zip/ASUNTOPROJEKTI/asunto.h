#ifndef ASUNTO_H
#define ASUNTO_H
#include <iostream>
using namespace std;
class Asunto
{
public:
    asunto();
    void maarita(int,int);
    double calculateConsumtion(double);

    int residents;
    int squares;

};

#endif // ASUNTO_H
