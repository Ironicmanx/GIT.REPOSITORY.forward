#ifndef KATUTASO_H
#define KATUTASO_H


class katutaso
{
public:
    katutaso();
};

#endif // KATUTASO_H
