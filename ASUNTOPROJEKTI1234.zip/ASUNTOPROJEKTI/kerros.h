#ifndef KERROS_H
#define KERROS_H


class kerros
{
public:
    kerros();






private:

protected:



};

#endif // KERROS_H
